/**
 * Stakeholder 3D dashboard — Plotly.js scatter3d + optional 2D projection.
 * All parsing runs in your browser; see index.html comments for external script URLs.
 *
 * Parquet: hyparquet is loaded only when you open a .parquet file (dynamic import).
 * Snappy + uncompressed work out of the box; gzip/brotli/zstd need extra packages (see hyparquet docs).
 */
const PARQUET_MODULE_URL =
  "https://cdn.jsdelivr.net/npm/hyparquet@1.12.0/src/hyparquet.min.js";

const CONFIG = {
  /** Default file when served over http(s); use demo-data.csv for the Ohio public-health sample */
  dataUrl: "demo-data.csv",
  columns: {
    x: "access_score",
    y: "prevention_uptake",
    z: "care_continuity",
    cluster: "ohio_region",
    shape: "service_type",
    size: "people_reached",
    details: "plain_summary",
  },
  hull: {
    alphahull: 6,
    opacity: 0.2,
    minPoints: 8,
  },
  marker: {
    sizeMin: 5,
    sizeMax: 22,
    scaleAsVolume: false,
  },
  defaultSymbol: "circle",
  visual: {
    sceneBackground: "#ffffff",
    paperBackground: "#ffffff",
    axisTextColor: "#0a0a0a",
    axisLineColor: "#000000",
    gridColor: "rgba(0, 0, 0, 0.14)",
    zeroLineColor: "rgba(0, 0, 0, 0.4)",
    axisPlaneColor: "#f1f5f9",
    showAxisBackdropPlanes: false,
  },
  /** Initial UI state */
  view: {
    defaultMode: "3d",
    /**
     * 2D only — what to do with depth (Z) or alternate encoding:
     * z_size | z_color | z_both | z_opacity | metric_size
     */
    defaultCollapseEncoding: "z_size",
  },
};

/** 2D depth encoding modes (also used in HTML <option value="...">) */
const COLLAPSE_ENCODING = {
  Z_SIZE: "z_size",
  Z_COLOR: "z_color",
  Z_BOTH: "z_both",
  Z_OPACITY: "z_opacity",
  METRIC_SIZE: "metric_size",
};

const CLUSTER_COLORS = [
  "#2563eb",
  "#7c3aed",
  "#0891b2",
  "#ea580c",
  "#db2777",
  "#16a34a",
  "#ca8a04",
  "#dc2626",
  "#475569",
  "#0d9488",
];

const SHAPE_SYMBOL_MAP = {
  circle: "circle",
  sphere: "circle",
  dot: "circle",
  clinic: "circle",
  square: "square",
  cube: "square",
  mobile_unit: "square",
  diamond: "diamond",
  telehealth: "diamond",
  triangle: "triangle-up",
  triangle_up: "triangle-up",
  pyramid: "triangle-up",
  school_site: "triangle-up",
  cross: "cross",
  x: "x",
  pharmacy_partner: "cross",
};

let lastRecords = [];
let viewMode = CONFIG.view.defaultMode;
let collapseEncoding = CONFIG.view.defaultCollapseEncoding;

const plotHost = document.getElementById("plot-host");
const sidebarPlaceholder = document.getElementById("sidebar-placeholder");
const detailPanel = document.getElementById("detail-panel");
const dataFileInput = document.getElementById("data-file-input");
const dataStatus = document.getElementById("data-status");
const dropOverlay = document.getElementById("drop-overlay");
const dropDismiss = document.getElementById("drop-dismiss");
const axisBackdropToggle = document.getElementById("axis-backdrop-toggle");
const backdropWrap = document.getElementById("backdrop-wrap");
const viewMode3d = document.getElementById("view-mode-3d");
const viewMode2d = document.getElementById("view-mode-2d");
const collapseEncodingSelect = document.getElementById("collapse-encoding");
const canvasLabel = document.getElementById("canvas-label");
const encodingHint = document.getElementById("encoding-hint");
const twoDOptions = document.getElementById("two-d-options");

function ensurePlotly() {
  return new Promise((resolve, reject) => {
    if (typeof Plotly !== "undefined" && Plotly.newPlot) {
      resolve();
      return;
    }
    const t0 = Date.now();
    const id = setInterval(() => {
      if (typeof Plotly !== "undefined" && Plotly.newPlot) {
        clearInterval(id);
        resolve();
      } else if (Date.now() - t0 > 15000) {
        clearInterval(id);
        reject(new Error("Plotly.js failed to load from the CDN."));
      }
    }, 50);
  });
}

function readFileAsText(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result || ""));
    r.onerror = () => reject(new Error("Could not read file as text."));
    r.readAsText(file);
  });
}

function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error("Could not read file."));
    r.readAsArrayBuffer(file);
  });
}

function normalizeRowObjects(rows) {
  return rows.map((row) => {
    const o = {};
    if (!row || typeof row !== "object") return o;
    for (const k of Object.keys(row)) {
      const key = String(k).trim();
      const v = row[k];
      if (v === null || v === undefined) o[key] = "";
      else if (typeof v === "bigint") o[key] = String(v);
      else if (typeof v === "number" && Number.isFinite(v)) o[key] = String(v);
      else o[key] = String(v).trim();
    }
    return o;
  });
}

/**
 * Keeps CSV/Excel text readable when files use Unicode dashes/quotes or when
 * some editors save UTF-8 but tools display classic mojibake (e.g. â€").
 */
function normalizeImportedText(s) {
  let t = String(s == null ? "" : s);
  t = t.replace(/[\u2013\u2014]/g, " - ");
  t = t.replace(/\u2018|\u2019|\u201C|\u201D/g, "'");
  // UTF-8 bytes mis-decoded as Windows-1252 (common for dash and apostrophe in CSV/Excel)
  t = t.replace(/\u00e2\u20ac\u2122/g, "'");
  // em/en dash stored as UTF-8 but opened as CP1252 often becomes euro + curly quote
  t = t.replace(/\u00e2\u20ac\u201c/g, " - ");
  t = t.replace(/\u00e2\u20ac\u201d/g, " - ");
  return t.trim();
}

function normalizeRecordStrings(records) {
  for (const r of records) {
    if (!r || typeof r !== "object") continue;
    for (const k of Object.keys(r)) {
      r[k] = normalizeImportedText(r[k]);
    }
  }
}

function parseCSV(text) {
  const rows = [];
  let i = 0;
  const len = text.length;
  let row = [];
  let field = "";
  let inQuotes = false;

  while (i < len) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i++;
        continue;
      }
      field += c;
      i++;
      continue;
    }
    if (c === '"') {
      inQuotes = true;
      i++;
      continue;
    }
    if (c === ",") {
      row.push(field);
      field = "";
      i++;
      continue;
    }
    if (c === "\r") {
      i++;
      continue;
    }
    if (c === "\n") {
      row.push(field);
      if (row.some((cell) => String(cell).length > 0)) rows.push(row);
      row = [];
      field = "";
      i++;
      continue;
    }
    field += c;
    i++;
  }
  row.push(field);
  if (row.some((cell) => String(cell).length > 0)) rows.push(row);

  if (rows.length < 2) return { headers: [], records: [] };
  const headers = rows[0].map((h) => String(h).trim());
  const records = [];
  for (let r = 1; r < rows.length; r++) {
    const cells = rows[r];
    if (cells.every((c) => String(c).trim() === "")) continue;
    const rec = {};
    for (let c = 0; c < headers.length; c++) {
      rec[headers[c]] = cells[c] !== undefined ? String(cells[c]).trim() : "";
    }
    records.push(rec);
  }
  return { headers, records };
}

function parseXlsxBuffer(buf) {
  if (typeof XLSX === "undefined") {
    throw new Error("Excel support: the XLSX script did not load. Check your network or use CSV.");
  }
  const wb = XLSX.read(buf, { type: "array" });
  const name = wb.SheetNames[0];
  if (!name) return { headers: [], records: [] };
  const sheet = wb.Sheets[name];
  const json = XLSX.utils.sheet_to_json(sheet, { defval: "", raw: false });
  const records = normalizeRowObjects(json);
  const headers = records[0] ? Object.keys(records[0]) : [];
  return { headers, records };
}

async function parseParquetBuffer(arrayBuffer) {
  let parquetReadObjects;
  try {
    ({ parquetReadObjects } = await import(PARQUET_MODULE_URL));
  } catch (e) {
    console.warn(e);
    throw new Error(
      "Could not load the Parquet reader module. Check the URL in script.js (PARQUET_MODULE_URL) or use CSV/XLSX."
    );
  }
  let data;
  try {
    data = await parquetReadObjects({ file: arrayBuffer });
  } catch (e) {
    console.warn(e);
    throw new Error(
      e.message ||
        "Parquet read failed. Try Snappy/uncompressed files, or convert to CSV. Gzip/Brotli/Zstd may need hyparquet-compressors (see hyparquet README)."
    );
  }
  const records = normalizeRowObjects(data);
  const headers = records[0] ? Object.keys(records[0]) : [];
  return { headers, records };
}

async function parseAnyFile(file) {
  const name = file.name.toLowerCase();
  if (name.endsWith(".csv") || file.type === "text/csv") {
    const text = await readFileAsText(file);
    return parseCSV(text);
  }
  if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
    const buf = await readFileAsArrayBuffer(file);
    return parseXlsxBuffer(buf);
  }
  if (name.endsWith(".parquet")) {
    const buf = await readFileAsArrayBuffer(file);
    return parseParquetBuffer(buf);
  }
  throw new Error("Unsupported file type. Use .csv, .xlsx, .xls, or .parquet.");
}

function col(records, key) {
  return records.map((r) => r[key]).filter((v) => v !== undefined);
}

function toNumber(s) {
  if (s === "" || s === null || s === undefined) return NaN;
  return Number(String(s).replace(/,/g, ""));
}

function uniqueSorted(values) {
  return [...new Set(values.map((v) => String(v)))].sort((a, b) =>
    a.localeCompare(b, undefined, { sensitivity: "base" })
  );
}

function normalizeKey(s) {
  return String(s).trim().toLowerCase().replace(/\s+/g, "_");
}

function resolveSymbol(shapeLabel) {
  const key = normalizeKey(shapeLabel);
  if (SHAPE_SYMBOL_MAP[key]) return SHAPE_SYMBOL_MAP[key];
  return CONFIG.defaultSymbol;
}

function clusterColorMap(clusterIds) {
  const map = {};
  clusterIds.forEach((id, idx) => {
    map[id] = CLUSTER_COLORS[idx % CLUSTER_COLORS.length];
  });
  return map;
}

function scaleSizes(metrics, minPx, maxPx, asVolume) {
  const raw = metrics.map((m) => toNumber(m));
  const usable = raw.map((n) => {
    if (Number.isNaN(n) || n < 0) return NaN;
    return asVolume ? Math.cbrt(n) : n;
  });
  const nums = usable.filter((n) => !Number.isNaN(n));
  if (nums.length === 0) return metrics.map(() => (minPx + maxPx) / 2);
  const lo = Math.min(...nums);
  const hi = Math.max(...nums);
  if (hi === lo) return metrics.map(() => (minPx + maxPx) / 2);
  return metrics.map((_, i) => {
    const v = usable[i];
    if (Number.isNaN(v)) return minPx;
    const t = (v - lo) / (hi - lo);
    return minPx + t * (maxPx - minPx);
  });
}

function scatterSizeRef(sizes) {
  const m = Math.max(...sizes, 1e-6);
  return m / CONFIG.marker.sizeMax;
}

function zExtent(records, zKey) {
  const vals = [];
  records.forEach((r) => {
    const z = toNumber(r[zKey]);
    if (!Number.isNaN(z)) vals.push(z);
  });
  if (!vals.length) return { zMin: 0, zMax: 1 };
  return { zMin: Math.min(...vals), zMax: Math.max(...vals) };
}

function setDropOverlayVisible(show, dragOver) {
  if (!dropOverlay) return;
  dropOverlay.classList.toggle("hidden", !show);
  dropOverlay.classList.toggle("drag-over", !!dragOver);
}

function setStatus(msg, isError) {
  if (!dataStatus) return;
  dataStatus.textContent = msg || "";
  dataStatus.style.color = isError ? "#dc2626" : "";
}

function validateColumns(headers, cfg) {
  const need = Object.values(cfg.columns);
  return need.filter((h) => !headers.includes(h));
}

function buildTraces(records, cfg) {
  const C = cfg.columns;
  const keys = ["x", "y", "z", "cluster", "shape", "size", "details"];
  const missing = keys.filter((k) => !records[0] || !(C[k] in records[0]));
  if (missing.length) {
    throw new Error(
      `Missing columns (check CONFIG.columns): ${missing.map((k) => C[k]).join(", ")}`
    );
  }

  const clusters = uniqueSorted(col(records, C.cluster));
  const colors = clusterColorMap(clusters);
  const traces = [];

  const comboKeys = [];
  const comboSet = new Set();
  records.forEach((r) => {
    const ck = `${r[C.cluster]}|||${r[C.shape]}`;
    if (!comboSet.has(ck)) {
      comboSet.add(ck);
      comboKeys.push({ cluster: r[C.cluster], shape: r[C.shape] });
    }
  });

  comboKeys.sort((a, b) => {
    const ca = String(a.cluster).localeCompare(String(b.cluster));
    if (ca !== 0) return ca;
    return String(a.shape).localeCompare(String(b.shape));
  });

  const seenLegendCluster = new Set();
  const sizesScaled = scaleSizes(
    col(records, C.size),
    cfg.marker.sizeMin,
    cfg.marker.sizeMax,
    cfg.marker.scaleAsVolume
  );
  const sizeByRow = new Map();
  records.forEach((r, i) => sizeByRow.set(r, sizesScaled[i]));

  comboKeys.forEach(({ cluster, shape }) => {
    const xs = [];
    const ys = [];
    const zs = [];
    const ms = [];
    const custom = [];
    const hoverText = [];

    records.forEach((r) => {
      if (r[C.cluster] !== cluster || r[C.shape] !== shape) return;
      const x = toNumber(r[C.x]);
      const y = toNumber(r[C.y]);
      const z = toNumber(r[C.z]);
      if (Number.isNaN(x) || Number.isNaN(y) || Number.isNaN(z)) return;
      xs.push(x);
      ys.push(y);
      zs.push(z);
      const siz = sizeByRow.get(r) ?? cfg.marker.sizeMin;
      ms.push(siz);
      custom.push([
        r[C.cluster],
        r[C.shape],
        r[C.size],
        r[C.details],
        r[C.x],
        r[C.y],
        r[C.z],
      ]);
      hoverText.push(
        `<b>${escapeHtml(cluster)}</b><br>` +
          `${escapeHtml(C.shape)}: ${escapeHtml(String(r[C.shape]))}<br>` +
          `${escapeHtml(C.z)}: ${escapeHtml(String(r[C.z]))}<br>` +
          `${escapeHtml(C.size)}: ${escapeHtml(String(r[C.size]))}`
      );
    });

    if (xs.length === 0) return;

    const color = colors[cluster];
    const sym = resolveSymbol(shape);
    const showLeg = !seenLegendCluster.has(cluster);
    if (showLeg) seenLegendCluster.add(cluster);

    traces.push({
      type: "scatter3d",
      mode: "markers",
      name: String(cluster),
      legendgroup: String(cluster),
      showlegend: showLeg,
      x: xs,
      y: ys,
      z: zs,
      text: hoverText,
      hoverinfo: "text",
      marker: {
        size: ms,
        sizemode: "diameter",
        sizeref: scatterSizeRef(ms),
        sizemin: cfg.marker.sizeMin,
        color,
        opacity: 0.95,
        line: { width: 0.5, color: "rgba(255,255,255,0.5)" },
        symbol: sym,
      },
      customdata: custom,
    });
  });

  clusters.forEach((cluster) => {
    const xs = [];
    const ys = [];
    const zs = [];
    records.forEach((r) => {
      if (r[C.cluster] !== cluster) return;
      const x = toNumber(r[C.x]);
      const y = toNumber(r[C.y]);
      const z = toNumber(r[C.z]);
      if (Number.isNaN(x) || Number.isNaN(y) || Number.isNaN(z)) return;
      xs.push(x);
      ys.push(y);
      zs.push(z);
    });
    if (xs.length < cfg.hull.minPoints) return;

    const hullColor = colors[cluster];
    traces.push({
      type: "mesh3d",
      legendgroup: String(cluster),
      showlegend: false,
      x: xs,
      y: ys,
      z: zs,
      alphahull: cfg.hull.alphahull,
      intensity: xs.map(() => 0),
      colorscale: [
        [0, hullColor],
        [1, hullColor],
      ],
      showscale: false,
      opacity: cfg.hull.opacity,
      flatshading: true,
      lighting: {
        ambient: 0.55,
        diffuse: 0.78,
        specular: 0.12,
        roughness: 0.45,
      },
      hoverinfo: "skip",
    });
  });

  return { traces, clusterColors: colors };
}

/**
 * 2D scatter on X–Y; hulls omitted. Encoding picks how Z (or size column) is shown.
 */
function buildTraces2D(records, cfg, encoding) {
  const C = cfg.columns;
  const keys = ["x", "y", "z", "cluster", "shape", "size", "details"];
  const missing = keys.filter((k) => !records[0] || !(C[k] in records[0]));
  if (missing.length) {
    throw new Error(
      `Missing columns (check CONFIG.columns): ${missing.map((k) => C[k]).join(", ")}`
    );
  }

  const { zMin, zMax } = zExtent(records, C.z);
  const zSpan = zMax - zMin || 1;

  const clusters = uniqueSorted(col(records, C.cluster));
  const colors = clusterColorMap(clusters);
  const traces = [];

  const comboKeys = [];
  const comboSet = new Set();
  records.forEach((r) => {
    const ck = `${r[C.cluster]}|||${r[C.shape]}`;
    if (!comboSet.has(ck)) {
      comboSet.add(ck);
      comboKeys.push({ cluster: r[C.cluster], shape: r[C.shape] });
    }
  });

  comboKeys.sort((a, b) => {
    const ca = String(a.cluster).localeCompare(String(b.cluster));
    if (ca !== 0) return ca;
    return String(a.shape).localeCompare(String(b.shape));
  });

  const seenLegendCluster = new Set();
  const sizeByRowMetric = new Map();
  const sizesFromMetric = scaleSizes(
    col(records, C.size),
    cfg.marker.sizeMin,
    cfg.marker.sizeMax,
    cfg.marker.scaleAsVolume
  );
  records.forEach((r, i) => sizeByRowMetric.set(r, sizesFromMetric[i]));

  let colorbarShown = false;

  comboKeys.forEach(({ cluster, shape }) => {
    const xs = [];
    const ys = [];
    const zs = [];
    const custom = [];
    const hoverText = [];

    records.forEach((r) => {
      if (r[C.cluster] !== cluster || r[C.shape] !== shape) return;
      const x = toNumber(r[C.x]);
      const y = toNumber(r[C.y]);
      const z = toNumber(r[C.z]);
      if (Number.isNaN(x) || Number.isNaN(y) || Number.isNaN(z)) return;
      xs.push(x);
      ys.push(y);
      zs.push(z);
      custom.push([
        r[C.cluster],
        r[C.shape],
        r[C.size],
        r[C.details],
        r[C.x],
        r[C.y],
        r[C.z],
      ]);
      hoverText.push(
        `<b>${escapeHtml(cluster)}</b><br>` +
          `${escapeHtml(C.x)}: ${escapeHtml(String(r[C.x]))}, ${escapeHtml(C.y)}: ${escapeHtml(
            String(r[C.y])
          )}<br>` +
          `${escapeHtml(C.z)}: ${escapeHtml(String(r[C.z]))}<br>` +
          `${escapeHtml(C.size)}: ${escapeHtml(String(r[C.size]))}`
      );
    });

    if (xs.length === 0) return;

    const clusterColor = colors[cluster];
    const sym = resolveSymbol(shape);
    const showLeg = !seenLegendCluster.has(cluster);
    if (showLeg) seenLegendCluster.add(cluster);

    const base = {
      type: "scatter",
      mode: "markers",
      name: String(cluster),
      legendgroup: String(cluster),
      showlegend: showLeg,
      x: xs,
      y: ys,
      text: hoverText,
      hoverinfo: "text",
      customdata: custom,
    };

    const zSizes = scaleSizes(
      zs.map(String),
      cfg.marker.sizeMin,
      cfg.marker.sizeMax,
      false
    );

    if (encoding === COLLAPSE_ENCODING.Z_SIZE) {
      traces.push({
        ...base,
        marker: {
          size: zSizes,
          sizemode: "diameter",
          sizeref: scatterSizeRef(zSizes),
          sizemin: cfg.marker.sizeMin,
          color: clusterColor,
          opacity: 0.92,
          line: { width: 0.6, color: "rgba(0,0,0,0.25)" },
          symbol: sym,
        },
      });
      return;
    }

    if (encoding === COLLAPSE_ENCODING.METRIC_SIZE) {
      const sizes = [];
      records.forEach((r) => {
        if (r[C.cluster] !== cluster || r[C.shape] !== shape) return;
        const x = toNumber(r[C.x]);
        const y = toNumber(r[C.y]);
        const z = toNumber(r[C.z]);
        if (Number.isNaN(x) || Number.isNaN(y) || Number.isNaN(z)) return;
        sizes.push(sizeByRowMetric.get(r) ?? cfg.marker.sizeMin);
      });
      traces.push({
        ...base,
        marker: {
          size: sizes,
          sizemode: "diameter",
          sizeref: scatterSizeRef(sizes),
          sizemin: cfg.marker.sizeMin,
          color: clusterColor,
          opacity: 0.92,
          line: { width: 0.6, color: "rgba(0,0,0,0.25)" },
          symbol: sym,
        },
      });
      return;
    }

    if (encoding === COLLAPSE_ENCODING.Z_OPACITY) {
      const opacities = zs.map((z) => 0.35 + (0.65 * (z - zMin)) / zSpan);
      traces.push({
        ...base,
        marker: {
          size: cfg.marker.sizeMin + (cfg.marker.sizeMax - cfg.marker.sizeMin) * 0.45,
          sizemode: "diameter",
          color: clusterColor,
          opacity: opacities,
          line: { width: 0.5, color: "rgba(0,0,0,0.2)" },
          symbol: sym,
        },
      });
      return;
    }

    const useColorBar = !colorbarShown;
    if (useColorBar) colorbarShown = true;

    if (encoding === COLLAPSE_ENCODING.Z_COLOR) {
      traces.push({
        ...base,
        marker: {
          size: cfg.marker.sizeMin + (cfg.marker.sizeMax - cfg.marker.sizeMin) * 0.5,
          sizemode: "diameter",
          color: zs,
          cmin: zMin,
          cmax: zMax,
          colorscale: "Viridis",
          showscale: useColorBar,
          colorbar: useColorBar
            ? {
                title: { text: C.z, font: { color: CONFIG.visual.axisTextColor, size: 11 } },
                tickfont: { color: CONFIG.visual.axisTextColor, size: 10 },
                outlinewidth: 0,
                thickness: 14,
              }
            : undefined,
          line: { width: 1.2, color: clusterColor },
          symbol: sym,
        },
      });
      return;
    }

    if (encoding === COLLAPSE_ENCODING.Z_BOTH) {
      traces.push({
        ...base,
        marker: {
          size: zSizes,
          sizemode: "diameter",
          sizeref: scatterSizeRef(zSizes),
          sizemin: cfg.marker.sizeMin,
          color: zs,
          cmin: zMin,
          cmax: zMax,
          colorscale: "Viridis",
          showscale: useColorBar,
          colorbar: useColorBar
            ? {
                title: { text: C.z, font: { color: CONFIG.visual.axisTextColor, size: 11 } },
                tickfont: { color: CONFIG.visual.axisTextColor, size: 10 },
                outlinewidth: 0,
                thickness: 14,
              }
            : undefined,
          line: { width: 1, color: clusterColor },
          symbol: sym,
        },
      });
      return;
    }
  });

  return { traces };
}

function sceneAxis(titleText) {
  const v = CONFIG.visual;
  return {
    title: {
      text: titleText,
      font: {
        family: "Segoe UI, system-ui, sans-serif",
        color: v.axisTextColor,
        size: 12,
      },
    },
    tickfont: { family: "Segoe UI, system-ui, sans-serif", color: v.axisTextColor, size: 10 },
    gridcolor: v.gridColor,
    gridwidth: 1,
    showgrid: true,
    zeroline: true,
    zerolinecolor: v.zeroLineColor,
    zerolinewidth: 1,
    showline: true,
    linecolor: v.axisLineColor,
    linewidth: 2,
    showbackground: v.showAxisBackdropPlanes,
    backgroundcolor: v.axisPlaneColor,
  };
}

function cartesianAxis(titleText) {
  const v = CONFIG.visual;
  return {
    title: {
      text: titleText,
      font: { family: "Segoe UI, system-ui, sans-serif", color: v.axisTextColor, size: 12 },
    },
    tickfont: { family: "Segoe UI, system-ui, sans-serif", color: v.axisTextColor, size: 10 },
    gridcolor: v.gridColor,
    zerolinecolor: v.zeroLineColor,
    showline: true,
    linecolor: v.axisLineColor,
    linewidth: 2,
    mirror: false,
  };
}

function plotLayout() {
  const C = CONFIG.columns;
  const v = CONFIG.visual;
  return {
    paper_bgcolor: v.paperBackground,
    plot_bgcolor: v.paperBackground,
    margin: { l: 0, r: 0, t: 28, b: 0 },
    font: { family: "Segoe UI, system-ui, sans-serif", color: v.axisTextColor, size: 11 },
    scene: {
      xaxis: sceneAxis(C.x),
      yaxis: sceneAxis(C.y),
      zaxis: sceneAxis(C.z),
      bgcolor: v.sceneBackground,
      camera: {
        eye: { x: 1.55, y: 1.45, z: 1.25 },
        center: { x: 0, y: 0, z: 0 },
      },
      aspectmode: "data",
      dragmode: "orbit",
    },
    legend: legendBlock(),
    hoverlabel: hoverBlock(),
  };
}

function plotLayout2D(encoding) {
  const C = CONFIG.columns;
  const v = CONFIG.visual;
  const needsColorbar =
    encoding === COLLAPSE_ENCODING.Z_COLOR || encoding === COLLAPSE_ENCODING.Z_BOTH;
  const note =
    encoding === COLLAPSE_ENCODING.Z_COLOR || encoding === COLLAPSE_ENCODING.Z_BOTH
      ? `Fill color = ${C.z} (color bar). Outline color hints at cluster. Legend still shows/hides groups.`
      : null;
  return {
    paper_bgcolor: v.paperBackground,
    plot_bgcolor: v.paperBackground,
    margin: { l: 58, r: needsColorbar ? 72 : 52, t: note ? 48 : 36, b: 52 },
    font: { family: "Segoe UI, system-ui, sans-serif", color: v.axisTextColor, size: 11 },
    xaxis: {
      ...cartesianAxis(C.x),
    },
    yaxis: {
      ...cartesianAxis(C.y),
    },
    legend: legendBlock(),
    hoverlabel: hoverBlock(),
    annotations: note
      ? [
          {
            text: note,
            showarrow: false,
            x: 0,
            y: 1.02,
            xref: "paper",
            yref: "paper",
            xanchor: "left",
            yanchor: "bottom",
            font: { size: 10, color: "rgba(0,0,0,0.55)" },
          },
        ]
      : [],
  };
}

function legendBlock() {
  const v = CONFIG.visual;
  return {
    x: 0.02,
    y: 0.98,
    bgcolor: "rgba(255, 255, 255, 0.94)",
    bordercolor: "rgba(0, 0, 0, 0.1)",
    borderwidth: 1,
    font: { size: 11, color: v.axisTextColor },
    tracegroupgap: 0,
    groupclick: "togglegroup",
    itemsizing: "constant",
    itemclick: "toggle",
    itemdoubleclick: "toggleothers",
  };
}

function hoverBlock() {
  const v = CONFIG.visual;
  return {
    bgcolor: "#ffffff",
    bordercolor: "rgba(0, 0, 0, 0.12)",
    font: { family: "Segoe UI, system-ui, sans-serif", size: 12, color: v.axisTextColor },
  };
}

function relayoutAxisBackdrops() {
  if (!plotHost || !plotHost.data || !plotHost.data.length || viewMode !== "3d") return;
  const show = CONFIG.visual.showAxisBackdropPlanes;
  const v = CONFIG.visual;
  const patch = {
    "scene.xaxis.showbackground": show,
    "scene.yaxis.showbackground": show,
    "scene.zaxis.showbackground": show,
  };
  if (show) {
    patch["scene.xaxis.backgroundcolor"] = v.axisPlaneColor;
    patch["scene.yaxis.backgroundcolor"] = v.axisPlaneColor;
    patch["scene.zaxis.backgroundcolor"] = v.axisPlaneColor;
  }
  Plotly.relayout(plotHost, patch);
}

function syncAxisBackdropToggle() {
  if (axisBackdropToggle) {
    axisBackdropToggle.checked = CONFIG.visual.showAxisBackdropPlanes;
  }
}

const plotConfig = {
  responsive: true,
  displaylogo: false,
  scrollZoom: true,
  modeBarButtonsToRemove: ["toImage", "sendDataToCloud"],
};

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function renderDetailSidebar(point) {
  const C = CONFIG.columns;
  const cd = point.customdata;
  if (!cd || !Array.isArray(cd)) return;

  const [cluster, shape, sizeMetric, detailed, rawX, rawY, rawZ] = cd;

  detailPanel.innerHTML = `
    <h3 class="detail-section-title">${escapeHtml(C.details)}</h3>
    <p class="detail-lead">${escapeHtml(String(detailed || "—"))}</p>
    <div class="metric-grid">
      <div class="metric-card">
        <div class="metric-label">${escapeHtml(C.cluster)}</div>
        <div class="metric-value">${escapeHtml(String(cluster))}</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">${escapeHtml(C.shape)}</div>
        <div class="metric-value">${escapeHtml(String(shape))}</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">${escapeHtml(C.size)}</div>
        <div class="metric-value">${escapeHtml(String(sizeMetric))}</div>
      </div>
      <div class="metric-card">
        <div class="metric-label">Coordinates (${escapeHtml(C.x)}, ${escapeHtml(C.y)}, ${escapeHtml(C.z)})</div>
        <div class="metric-value">${escapeHtml(String(rawX))}, ${escapeHtml(String(rawY))}, ${escapeHtml(
    String(rawZ)
  )}</div>
      </div>
    </div>
  `;

  sidebarPlaceholder.classList.add("hidden");
  detailPanel.classList.remove("hidden");
}

function resetSidebar() {
  detailPanel.innerHTML = "";
  detailPanel.classList.add("hidden");
  sidebarPlaceholder.classList.remove("hidden");
}

function bindPlotEvents() {
  plotHost.on("plotly_click", (ev) => {
    const p = ev.points && ev.points[0];
    if (!p || (p.data.type !== "scatter3d" && p.data.type !== "scatter")) return;
    renderDetailSidebar(p);
  });
}

function updateViewChrome() {
  const is3d = viewMode === "3d";
  if (canvasLabel) {
    canvasLabel.textContent = is3d ? "3D view" : "2D projection (X–Y)";
  }
  if (backdropWrap) {
    backdropWrap.classList.toggle("hidden", !is3d);
    backdropWrap.setAttribute("aria-hidden", is3d ? "false" : "true");
  }
  if (twoDOptions) {
    twoDOptions.classList.toggle("hidden", is3d);
    twoDOptions.setAttribute("aria-hidden", is3d ? "true" : "false");
  }
  if (viewMode3d) viewMode3d.setAttribute("aria-pressed", is3d ? "true" : "false");
  if (viewMode2d) viewMode2d.setAttribute("aria-pressed", is3d ? "false" : "true");

  const hints = {
    [COLLAPSE_ENCODING.Z_SIZE]:
      "Recommended default: region color stays familiar; larger dots = stronger care continuity.",
    [COLLAPSE_ENCODING.Z_COLOR]:
      "Like a weather map: color = care continuity (Viridis). Slightly harder for color-blind viewers—prefer size when possible.",
    [COLLAPSE_ENCODING.Z_BOTH]:
      "Rich but busy: both size and color track care continuity. Best for exploration, not one-glance slides.",
    [COLLAPSE_ENCODING.Z_OPACITY]:
      "Fainter = lower care continuity. Subtle; weaker for accessibility than size or color alone.",
    [COLLAPSE_ENCODING.METRIC_SIZE]:
      "Dot size follows people reached; care continuity stays in hover and the sidebar.",
  };
  if (encodingHint) {
    encodingHint.textContent = is3d ? "" : hints[collapseEncoding] || "";
  }
}

function syncEncodingSelect() {
  if (collapseEncodingSelect) {
    collapseEncodingSelect.value = collapseEncoding;
  }
}

async function drawPlotFromRecords(records) {
  normalizeRecordStrings(records);
  lastRecords = records;
  resetSidebar();
  if (!records.length) {
    setStatus("No data rows found.", true);
    return;
  }

  let traces;
  let layout;
  try {
    if (viewMode === "3d") {
      traces = buildTraces(records, CONFIG).traces;
      layout = plotLayout();
    } else {
      traces = buildTraces2D(records, CONFIG, collapseEncoding).traces;
      layout = plotLayout2D(collapseEncoding);
    }
  } catch (e) {
    setStatus(e.message || "Plot error", true);
    return;
  }

  if (!traces.length) {
    setStatus("No valid numeric coordinates to plot.", true);
    return;
  }

  try {
    if (plotHost.data && plotHost.data.length) Plotly.purge(plotHost);
  } catch (_) {
    /* first render */
  }

  await Plotly.newPlot(plotHost, traces, layout, plotConfig);
  updateViewChrome();
  syncAxisBackdropToggle();
  syncEncodingSelect();
  bindPlotEvents();

  const n = records.length;
  if (viewMode === "3d") {
    setStatus(`${n} rows · 3D: drag to rotate, scroll to zoom`, false);
  } else {
    setStatus(`${n} rows · 2D: drag to pan, scroll to zoom`, false);
  }
}

async function loadTextAndDraw(text, label) {
  const { headers, records } = parseCSV(text);
  const miss = validateColumns(headers, CONFIG);
  if (miss.length) {
    setStatus(`Data missing columns: ${miss.join(", ")}`, true);
    setDropOverlayVisible(true, false);
    return;
  }
  setDropOverlayVisible(false, false);
  await drawPlotFromRecords(records);
  if (label) setStatus(`${label} · ${records.length} rows`, false);
}

async function tryFetchCsv() {
  const isFile = window.location.protocol === "file:";
  if (isFile) {
    setDropOverlayVisible(true, false);
    setStatus(`Use Load data or drop a file (CSV / Excel / Parquet).`, false);
    return;
  }
  try {
    const res = await fetch(CONFIG.dataUrl, { cache: "no-store" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    await loadTextAndDraw(text, CONFIG.dataUrl);
  } catch (e) {
    console.warn(e);
    setDropOverlayVisible(true, false);
    setStatus(`Could not fetch ${CONFIG.dataUrl}. Use Load data.`, true);
  }
}

async function onDataFile(f) {
  if (!f) return;
  setStatus("Reading file…", false);
  try {
    const { headers, records } = await parseAnyFile(f);
    const miss = validateColumns(headers, CONFIG);
    if (miss.length) {
      setStatus(`Data missing columns: ${miss.join(", ")}`, true);
      return;
    }
    await drawPlotFromRecords(records);
    setStatus(`${f.name} · ${records.length} rows`, false);
    setDropOverlayVisible(false, false);
  } catch (e) {
    console.warn(e);
    setStatus(e.message || "Could not read file.", true);
  }
}

window.addEventListener("resize", () => {
  try {
    Plotly.Plots.resize(plotHost);
  } catch (_) {
    /* no plot */
  }
});

dataFileInput.addEventListener("change", (e) => {
  const f = e.target.files && e.target.files[0];
  onDataFile(f);
  e.target.value = "";
});

dropDismiss?.addEventListener("click", () => setDropOverlayVisible(false, false));

axisBackdropToggle?.addEventListener("change", () => {
  CONFIG.visual.showAxisBackdropPlanes = axisBackdropToggle.checked;
  relayoutAxisBackdrops();
});

viewMode3d?.addEventListener("click", async () => {
  viewMode = "3d";
  updateViewChrome();
  if (lastRecords.length) await drawPlotFromRecords(lastRecords);
});

viewMode2d?.addEventListener("click", async () => {
  viewMode = "2d";
  updateViewChrome();
  if (lastRecords.length) await drawPlotFromRecords(lastRecords);
});

collapseEncodingSelect?.addEventListener("change", async () => {
  collapseEncoding = collapseEncodingSelect.value;
  updateViewChrome();
  if (lastRecords.length && viewMode === "2d") await drawPlotFromRecords(lastRecords);
});

if (dropOverlay) {
  dropOverlay.addEventListener("click", (e) => {
    if (e.target === dropOverlay) setDropOverlayVisible(false, false);
  });
}

["dragenter", "dragover"].forEach((evt) => {
  window.addEventListener(evt, (e) => {
    if (![...e.dataTransfer.types].includes("Files")) return;
    e.preventDefault();
    if (dropOverlay && !dropOverlay.classList.contains("hidden")) {
      setDropOverlayVisible(true, true);
    }
  });
});

window.addEventListener("dragleave", (e) => {
  if (e.relatedTarget === null && dropOverlay) {
    dropOverlay.classList.remove("drag-over");
  }
});

const DATA_EXT = /\.(csv|xlsx|xls|parquet)$/i;

window.addEventListener("drop", (e) => {
  e.preventDefault();
  dropOverlay?.classList.remove("drag-over");
  const f = e.dataTransfer.files && e.dataTransfer.files[0];
  if (!f) return;
  if (!DATA_EXT.test(f.name)) {
    setStatus("Please drop .csv, .xlsx, .xls, or .parquet.", true);
    return;
  }
  onDataFile(f);
  setDropOverlayVisible(false, false);
});

document.addEventListener("DOMContentLoaded", async () => {
  viewMode = CONFIG.view.defaultMode;
  collapseEncoding = CONFIG.view.defaultCollapseEncoding;
  syncAxisBackdropToggle();
  syncEncodingSelect();
  updateViewChrome();
  try {
    await ensurePlotly();
  } catch (e) {
    setStatus(e.message || "Plotly load error", true);
    return;
  }
  await tryFetchCsv();
});
