param(
  [string]$inputPath = "c:\Users\samab\.cursor\projects\c-Users-samab-OneDrive-Documents\agent-transcripts\54b4f3f1-541f-4488-9b28-170fb2777611\54b4f3f1-541f-4488-9b28-170fb2777611.jsonl",
  [string]$outDir = "c:\Users\samab\OneDrive\Documents\stakeholder-3d-dashboard"
)

$ErrorActionPreference = "Stop"

if (!(Test-Path -LiteralPath $outDir)) {
  New-Item -ItemType Directory -Path $outDir | Out-Null
}

$prompts = New-Object System.Collections.Generic.List[string]
$responses = New-Object System.Collections.Generic.List[System.Collections.Generic.List[string]]
$lastIndex = -1

foreach ($line in Get-Content -LiteralPath $inputPath) {
  if ([string]::IsNullOrWhiteSpace($line)) { continue }

  try {
    $obj = $line | ConvertFrom-Json
  } catch {
    continue
  }

  if (-not $obj.message -or -not $obj.message.content) { continue }

  $role = $obj.role

  $textParts = @()
  foreach ($c in $obj.message.content) {
    if ($c.type -eq "text" -and -not [string]::IsNullOrWhiteSpace($c.text)) {
      $textParts += $c.text
    }
  }

  $text = ($textParts -join "`r`n`r`n")
  if ([string]::IsNullOrWhiteSpace($text)) { continue }

  if ($role -eq "user") {
    $m = [regex]::Match($text, "<user_query>([\s\S]*?)</user_query>")
    if ($m.Success) { $text = $m.Groups[1].Value.Trim() } else { $text = $text.Trim() }

    if (-not [string]::IsNullOrWhiteSpace($text)) {
      $prompts.Add($text)
      $responses.Add((New-Object System.Collections.Generic.List[string]))
      $lastIndex = $prompts.Count - 1
    }
  } elseif ($role -eq "assistant") {
    if ($lastIndex -ge 0) {
      $responses[$lastIndex].Add($text)
    }
  }
}

$promptsTxtPath = Join-Path $outDir "prompts.txt"
$responsesTxtPath = Join-Path $outDir "responses.txt"
$promptsPdfPath = Join-Path $outDir "prompts.pdf"

$promptsTxt = ""
for ($i = 0; $i -lt $prompts.Count; $i++) {
  $promptsTxt += ("{0}. {1}" -f ($i + 1), $prompts[$i]).Trim() + "`r`n`r`n"
}

$respTxt = ""
for ($i = 0; $i -lt $prompts.Count; $i++) {
  $joinedParts = $responses[$i] | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
  $joined = ($joinedParts -join "`r`n`r`n---`r`n`r`n").Trim()
  $respTxt += ("{0})" -f ($i + 1)) + "`r`n" + $joined + "`r`n`r`n"
}

Set-Content -LiteralPath $promptsTxtPath -Value $promptsTxt -Encoding UTF8
Set-Content -LiteralPath $responsesTxtPath -Value $respTxt -Encoding UTF8

Write-Host ("Exported prompts.txt + responses.txt to: {0}" -f $outDir)

# Export prompts to PDF using Word (local only)
try {
  $word = New-Object -ComObject Word.Application
  $word.Visible = $false

  $doc = $word.Documents.Add()
  $doc.Content.Text = $promptsTxt
  # ExportAsFixedFormat uses:
  #   ExportFormat = 17 -> PDF
  $doc.ExportAsFixedFormat($promptsPdfPath, 17) | Out-Null
  $doc.Close()
  $word.Quit()

  # Release COM objects defensively
  [void][System.Runtime.Interopservices.Marshal]::ReleaseComObject($doc)
  [void][System.Runtime.Interopservices.Marshal]::ReleaseComObject($word)

  Write-Host ("Exported prompts.pdf to: {0}" -f $promptsPdfPath)
} catch {
  Write-Host ("PDF export failed (Word COM not available?): " + $_.Exception.Message)
}

